### Hexlet tests and linter status:
[![Actions Status](https://github.com/LostCupcake/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/LostCupcake/python-project-49/actions)

<a href="https://codeclimate.com/github/LostCupcake/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/9717bb7f1caeb3356929/maintainability" /></a>

[![asciicast](https://asciinema.org/a/5IHSniNpLEDMqI6ape6b2bJa3.svg)](https://asciinema.org/a/5IHSniNpLEDMqI6ape6b2bJa3)
